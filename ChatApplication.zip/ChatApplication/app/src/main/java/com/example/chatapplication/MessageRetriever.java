package com.example.chatapplication;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.os.AsyncTask;
import android.os.Build;

public class MessageRetriever extends AsyncTask<String, Message, Void> {

    @SuppressLint("StaticFieldLeak")
    private final ChatActivity activity;

    private final ChatIO crawler;

    /**
     * The server address
     */
    private final String serv;

    public MessageRetriever(ChatActivity activity, String serv) {
        this.activity = activity;
        this.crawler = new ChatIO();
        this.serv = serv;
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    @Override
    protected Void doInBackground(String... strings) {
        int count = 0;
        while (true) {
            if (isCancelled()) return null;
            try {
                Message m = this.crawler.fetchMessage(this.serv, "android", count);
                if (m == null) continue;
                publishProgress(m);
                count++;
            } catch (Exception ignored) {}
        }
    }

    @Override
    protected void onProgressUpdate(Message... values) {
        super.onProgressUpdate(values);
        for (Message message: values)
            this.activity.addReceivedMessage(message);
    }
}

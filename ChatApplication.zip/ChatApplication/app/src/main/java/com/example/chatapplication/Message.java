package com.example.chatapplication;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.text.format.DateFormat;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Objects;
import java.util.TimeZone;

public class Message {
    private final String queue;
    private final String author;
    private final long timestamp;
    private final String body;
    private final int id;
    private static int COUNT = 0;

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public Message(String queue, String author, String body, long timestamp){
        this.id = COUNT++;
        this.author = Objects.requireNonNull(author);
        this.body = Objects.requireNonNull(body);
        this.queue = Objects.requireNonNull(queue);
        this.timestamp = timestamp;
    }

    public String getQueue() {
        return queue;
    }

    public String getAuthor() {
        return author;
    }

    public String getBody() {
        return body;
    }

    public long getTimestamp(){ return this.timestamp; }

    /**
     * Convert JSON data into a message
     * @param json The message in JSON format
     * @return The message
     * @throws JSONException If the JSON is not correct
     */
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public static Message fromJSON(String json) throws JSONException {
        JSONObject d = new JSONObject(json);
        return new Message(
                "",
                d.getString("author"),
                d.getString("message"),
                d.getLong("timestamp")
        );
    }

}

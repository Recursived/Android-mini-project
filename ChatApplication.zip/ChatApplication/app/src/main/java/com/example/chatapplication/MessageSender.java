package com.example.chatapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.widget.Toast;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

public class MessageSender extends AsyncTask<Message, Void, Boolean> {

    @SuppressLint("StaticFieldLeak")
    private Context context;
    private HttpURLConnection conn;

    public MessageSender(Context context, String server, String queue, String author) {
        this.context = context;
        try {
            URL url = new URL("http://" + server + ":2019/" + queue + "?author=" + author);
            URLConnection conn = url.openConnection();
            this.conn = (HttpURLConnection) conn;
        } catch (Exception silenced) {}
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected Boolean doInBackground(Message... messages) {
        Message message = messages[0];
        try {
            ChatIO.post(this.conn, message.getBody());
            return Boolean.TRUE;
        } catch (Exception ignored) {
            return Boolean.FALSE;
        }
    }

    @Override
    protected void onPostExecute(Boolean aBoolean) {
        super.onPostExecute(aBoolean);
        if (!aBoolean) {
            String message = "Can't send the message, try again later";
            Toast.makeText(this.context, message, Toast.LENGTH_LONG).show();
        }
    }
}

package com.example.chatapplication;

import android.app.AlertDialog;
import android.os.AsyncTask;
import android.os.Build;
import android.os.SystemClock;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends AppCompatActivity {

    private final List<Message> messages = new ArrayList<>();
    private static final String SERV = "chat.plade.org";
    private String pseudo;
    private MessageRetriever mr;
    private MessageAdapter ma;
    private EditText et;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et = findViewById(R.id.editText);
        mr = new MessageRetriever(this, ChatActivity.SERV);
        ma =  new MessageAdapter(messages);
        mr.execute();
        RecyclerView rv = findViewById(R.id.recyclerView);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(ma);




    }

    @Override
    protected void onStart() {
        super.onStart();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View v = getLayoutInflater().inflate(R.layout.login_block, null);
        builder.setView(v);
        final EditText login_edittext = v.findViewById(R.id.editText_login);
        Button button_login = v.findViewById(R.id.button_login);
        final AlertDialog dialog = builder.create();
        dialog.setCancelable(false);
        dialog.show();




        button_login.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View x) {
                String p = login_edittext.getText().toString();
                if (p.equals("")) {
                    login_edittext.setError("You need a pseudo !");
                    return;
                }
                login_edittext.setError(null);
                ChatActivity.this.pseudo = p;
                dialog.dismiss();
            }
        });
    }

    private void clearChatList() {
        this.messages.clear();
        this.ma.notifyDataSetChanged();
    }

    public void addReceivedMessage(Message message) {
        this.messages.add(message);
        Log.i("liste des messages", this.messages.toString());
        this.ma.notifyDataSetChanged();
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void onSendMessage(View view) {
        Message m = new Message(
            "android",
                this.pseudo,
                et.getText().toString(),
                SystemClock.currentThreadTimeMillis()
        );

        MessageSender ms = new MessageSender(
                this,
                ChatActivity.SERV,
                m.getQueue(),
                m.getAuthor()
        );

        et.setText("");
        RecyclerView rc = findViewById(R.id.recyclerView);
        rc.smoothScrollToPosition(messages.size() - 1);

        ms.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, m);
        Log.i("info mesage", "jenvoie un message");
    }

    @Override
    protected void onPause() {
        super.onPause();
        this.mr.cancel(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (this.mr.isCancelled()) {
            this.clearChatList();
            this.mr = new MessageRetriever(this, ChatActivity.SERV);
            this.mr.execute();
        }
    }


}

package com.example.chatapplication;

import android.os.Build;
import android.support.annotation.RequiresApi;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;

import static java.nio.charset.StandardCharsets.UTF_8;

public class ChatIO {

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public Message fetchMessage(String server, String queue, int id) throws JSONException {
        String url = "http://" + server + ":2019/" + queue + "/" + id;
        String data = this.getStringFromURL(url);
        return Message.fromJSON(data);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private String getStringFromURL(String reqURL) {
        String parsed = "";
        try {
            URL url = new URL(reqURL);
            URLConnection conn = url.openConnection();
            HttpURLConnection httpConn = (HttpURLConnection) conn;
            httpConn.setAllowUserInteraction(false);
            httpConn.setInstanceFollowRedirects(true);
            httpConn.setRequestMethod("GET");
            httpConn.connect();

            InputStream istream = httpConn.getInputStream();
            parsed = convertInputStreamToString(istream);
        } catch (Exception silence) {}  // S'il y a erreur, on l'ignore
        return parsed;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private static String convertInputStreamToString(InputStream stream) throws IOException {
        // Si le stream est null, on retourne un chaine vide sinon on retourne la chaine de l'input stream
        if (stream != null) {
            StringBuilder sb = new StringBuilder();
            String line;

            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(
                        stream, StandardCharsets.UTF_8));
                while ((line = br.readLine()) != null) {
                    sb.append(line).append("\n");
                }
            } finally {
                stream.close();
            }
            return sb.toString();
        } else {
            return "";
        }
    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public static void post(HttpURLConnection conn, String message) throws IOException
    {
        byte[] data = JSONObject.quote(message).getBytes(StandardCharsets.UTF_8); // encodes the string in JSON and converts to byte using UTF-8
        conn.setDoOutput(true);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Content-Length", String.valueOf(data.length));
        conn.connect();
        try (OutputStream out = conn.getOutputStream()) {
            out.write(data);
        } catch (Exception ignored) {}
        conn.getResponseCode();
        conn.disconnect();
    }
}

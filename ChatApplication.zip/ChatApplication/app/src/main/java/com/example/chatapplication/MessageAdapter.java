package com.example.chatapplication;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageVH>{

    private List<Message> messages;

    MessageAdapter(List<Message> m){
        this.messages = m;
    }

    class MessageVH extends RecyclerView.ViewHolder{

        private final TextView author;
        private final TextView timestamp;
        private final TextView message;

        public MessageVH(@NonNull View itemView) {
            super(itemView);
            this.author = itemView.findViewById(R.id.author);
            this.timestamp = itemView.findViewById(R.id.time);
            this.message = itemView.findViewById(R.id.message);
        }

        void display(Message message) {
            this.author.setText(message.getAuthor());
            this.message.setText(message.getBody());
            Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT+1"));
            calendar.setTimeInMillis(message.getTimestamp() * 1000L);
            this.timestamp.setText(DateFormat.format("dd/MM/yyyy HH:mm:ss", calendar).toString());
        }


    }


    @NonNull
    @Override
    public MessageVH onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View v = inflater.inflate(R.layout.message_block, viewGroup, false);
        return new MessageVH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MessageVH messageVH, int i) {
        messageVH.display(messages.get(i));
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }





}
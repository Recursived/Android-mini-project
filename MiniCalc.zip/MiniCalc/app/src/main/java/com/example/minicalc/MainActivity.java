package com.example.minicalc;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    static int RESULT_FOR_OPE2 = 20;
    static int RESULT_FOR_OPE1 = 30;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickOpeOne(View view) {
        Intent intent = new Intent(this, KeyPadActivity.class);
        startActivityForResult(intent, RESULT_FOR_OPE1);
    }

    public void onClickOpeTwo(View view) {
        Intent intent = new Intent(this, KeyPadActivity.class);
        startActivityForResult(intent, RESULT_FOR_OPE2);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        TextView tv1 = findViewById(R.id.textView_zerope);
        TextView tv2 = findViewById(R.id.textView_first_op);
        // On effectue un traitement ssi on appuye sur envoyer
        if (resultCode != RESULT_CANCELED){
            Bundle b = data.getExtras();
            if( requestCode == RESULT_FOR_OPE1){
                tv1.setText((String) b.get("value"));
            } else if (requestCode == RESULT_FOR_OPE2){
                tv2.setText((String) b.get("value"));
            }
        }

        // quand les deux textes view op1 et op2 sont remplis, on enable les radios
        // sinon il reste disabled
        if (isNumeric(tv1.getText().toString()) && isNumeric(tv2.getText().toString())){
            findViewById(R.id.radioButton_div).setEnabled(true);
            findViewById(R.id.radioButton_mul).setEnabled(true);
            findViewById(R.id.radioButton_plus).setEnabled(true);
            findViewById(R.id.radioButton_moins).setEnabled(true);
        }
    }

    private boolean isNumeric(String strNum) {
        try {
            int d = Integer.parseInt(strNum);
        } catch (NumberFormatException | NullPointerException nfe) {
            return false;
        }
        return true;
    }

    public void onClickRadioButton(View view) {
        // En fonction de l'id, on effectue le calcul adéquat
        TextView tv = findViewById(R.id.textView_second_op);
        TextView tv1 = findViewById(R.id.textView_zerope);
        TextView tv2 = findViewById(R.id.textView_first_op);
        switch (view.getId()){
            case R.id.radioButton_plus:
                tv.setText(getResult(tv1.getText().toString(), tv2.getText().toString(), "+"));
                break;
            case R.id.radioButton_moins:
                tv.setText(getResult(tv1.getText().toString(), tv2.getText().toString(), "-"));
                break;
            case R.id.radioButton_div:
                tv.setText(getResult(tv1.getText().toString(), tv2.getText().toString(), "/"));
                break;
            case R.id.radioButton_mul:
                tv.setText(getResult(tv1.getText().toString(), tv2.getText().toString(), "*"));
                break;
        }
    }

    private String getResult(String firstop, String secondOp, String op) {
        TextView tv1 = findViewById(R.id.textView_zerope);
        TextView tv2 = findViewById(R.id.textView_first_op);
        try {
            int d = Integer.parseInt(tv1.getText().toString());
            int d1 = Integer.parseInt(tv2.getText().toString());
            int val;
            switch (op) {
                case "/":
                    val = d / d1;
                    return String.valueOf(val);
                case "*":
                    val = d * d1;
                    return String.valueOf(val);
                case "-":
                    val = d - d1;
                    return String.valueOf(val);
                case "+":
                    val = d + d1;
                    return String.valueOf(val);

            }

        } catch (NumberFormatException | NullPointerException nfe) {
            return "No value";
        }
        return "No Value";
    }

    public void onClickRightOp(View view) {
        TextView tv = findViewById(R.id.textView_second_op);
        TextView tv1 = findViewById(R.id.textView_zerope);
        TextView tv2 = findViewById(R.id.textView_first_op);
        tv2.setText(tv.getText().toString());
        RadioButton rb = findViewById(R.id.radioButton_div);
        RadioButton rb1 =findViewById(R.id.radioButton_mul);
        RadioButton rb2 = findViewById(R.id.radioButton_plus);

        if (rb.isChecked()){
            tv.setText(getResult(tv1.getText().toString(), tv2.getText().toString(), "/"));
        } else if (rb1.isChecked()){
            tv.setText(getResult(tv1.getText().toString(), tv2.getText().toString(), "*"));
        } else if (rb2.isChecked()){
            tv.setText(getResult(tv1.getText().toString(), tv2.getText().toString(), "+"));
        } else {
            tv.setText(getResult(tv1.getText().toString(), tv2.getText().toString(), "-"));
        }
    }

    public void onClickLeftOp(View view) {
        TextView tv = findViewById(R.id.textView_second_op);
        TextView tv1 = findViewById(R.id.textView_zerope);
        TextView tv2 = findViewById(R.id.textView_first_op);
        tv1.setText(tv.getText().toString());
        RadioButton rb = findViewById(R.id.radioButton_div);
        RadioButton rb1 =findViewById(R.id.radioButton_mul);
        RadioButton rb2 = findViewById(R.id.radioButton_plus);

        if (rb.isChecked()){
            tv.setText(getResult(tv1.getText().toString(), tv2.getText().toString(), "/"));
        } else if (rb1.isChecked()){
            tv.setText(getResult(tv1.getText().toString(), tv2.getText().toString(), "*"));
        } else if (rb2.isChecked()){
            tv.setText(getResult(tv1.getText().toString(), tv2.getText().toString(), "+"));
        } else {
            tv.setText(getResult(tv1.getText().toString(), tv2.getText().toString(), "-"));
        }

    }
}

package com.example.minicalc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

public class KeyPadActivity extends AppCompatActivity {
    private boolean isNegative = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_key_pad);
    }


    @Override
    public void onBackPressed() {
        Intent intent = new Intent();
        int resultCode = RESULT_CANCELED;
        setResult(resultCode, intent);
        finish();
    }

    public void onClickClear(View view) {
        TextView tv = findViewById(R.id.textView_show);
        if (this.isNegative){
            tv.setText("-");
        } else {
            tv.setText("");
        }
    }

    public void onClickBack(View view) {
        TextView tv = findViewById(R.id.textView_show);
        String str = tv.getText().toString();
        if (str != null && str.length() > 0 && !str.equals("-")) {
            str = str.substring(0, str.length() - 1);
        }
        tv.setText(str);
    }

    public void onClickValidate(View view) {
        Intent intent = new Intent();
        TextView tv = findViewById(R.id.textView_show);
        String str = tv.getText().toString();
        int resultCode;
        try {
            Integer d = Integer.parseInt(str);
            resultCode = RESULT_OK;
            intent.putExtra("value", str);
        } catch (NumberFormatException | NullPointerException nfe) {
            resultCode = RESULT_CANCELED;
        }

        setResult(resultCode, intent);
        finish();

    }


    public void onClickKeyPadNumber(View view) {
        TextView tv = findViewById(R.id.textView_show);
        String s = tv.getText().toString();
        CheckBox cb = findViewById(R.id.checkBox_neg);
        cb.setEnabled(true);
        if (this.isNumeric(s)){
            switch (view.getId()) {
                case R.id.button_one:
                    s+= "1";
                    break;
                case R.id.button_two:
                    s+= "2";
                    break;
                case R.id.button_three:
                    s+= "3";
                    break;
                case R.id.button_four:
                    s+=  "4";
                    break;
                case R.id.button_five:
                    s+=  "5";
                    break;
                case R.id.button_six:
                    s+=  "6";
                    break;
                case R.id.button_seven:
                    s+= "7";
                    break;
                case R.id.button_eight:
                    s+= "8";
                    break;
                case R.id.button_nine:
                    s+= "9";
                    break;
                case R.id.button_zero:
                    s+= "0";
                    break;
                default:
                    break;
            }
        } else {
            switch (view.getId()){
                case R.id.button_one:
                    s= "1";
                    break;
                case R.id.button_two:
                    s= "2";
                    break;
                case R.id.button_three:
                    s= "3";
                    break;
                case R.id.button_four:
                    s=  "4";
                    break;
                case R.id.button_five:
                    s=  "5";
                    break;
                case R.id.button_six:
                    s=  "6";
                    break;
                case R.id.button_seven:
                    s= "7";
                    break;
                case R.id.button_eight:
                    s= "8";
                    break;
                case R.id.button_nine:
                    s= "9";
                    break;
                case R.id.button_zero:
                    s= "0";
                    break;
                default:
                    break;
            }
        }
        tv.setText(s);
    }

    private boolean isNumeric(String strNum) {
        try {
            int d = Integer.parseInt(strNum);
        } catch (NumberFormatException | NullPointerException nfe) {
            if (strNum.equals("-") && strNum.length() == 1){
                return true;
            }
            return false;
        }
        return true;
    }

    public void onClickNegCheck(View view) {
        TextView tv = findViewById(R.id.textView_show);
        String s = tv.getText().toString();

        if (this.isNegative){
            // On le met en positif
            tv.setText(s.substring(1));
        } else {
            // On le met en negatif
            StringBuilder sb = new StringBuilder(s);
            sb.insert(0, "-");
            tv.setText(sb.toString());
        }
        this.isNegative = !this.isNegative;

    }
}

package com.example.countdown;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class RecentDurationsActivity extends AppCompatActivity {

    class myAdapter extends BaseAdapter {

        private final List<Integer> data;
        private final LayoutInflater inflater;

        public myAdapter(Context context, List<Integer> data) {
            this.data = data;
            this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null)
                convertView = inflater.inflate(android.R.layout.simple_list_item_1, parent, false);
            TextView content = convertView.findViewById(android.R.id.text1);
            long val = (long) (int) getItem(position);
            content.setText(String.format("%02d:%02d:%02d",
                    TimeUnit.MILLISECONDS.toHours(val),
                    TimeUnit.MILLISECONDS.toMinutes(val) -
                            TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(val)),
                    TimeUnit.MILLISECONDS.toSeconds(val) -
                            TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(val))));
            return convertView;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recent_durations);
        final List<Integer> l =  RecentDurations.getInstance().getRecentDurations(this);
        ListView lv = findViewById(R.id.list_item);
        lv.setAdapter(new myAdapter(this, l));
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i =  new Intent();
                i.putExtra("duration", l.get(position));
                int resultCode = RESULT_OK;
                setResult(resultCode, i);
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i =  new Intent();
        int resultCode = RESULT_CANCELED;
        setResult(resultCode, i);
        finish();
    }


}

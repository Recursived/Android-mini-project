package com.example.countdown;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

public class Clepsydra extends View {
    private double fillRatio = 1;
    Paint p = new Paint();
    Paint p2 = new Paint();


    public Clepsydra(Context context) {
        super(context);
        p.setColor(Color.GRAY);
        p2.setColor(Color.BLUE);
    }

    public Clepsydra(Context context, AttributeSet attrs) {
        super(context, attrs);
        p.setColor(Color.GRAY);
        p2.setColor(Color.BLUE);
    }

    public Clepsydra(Context context,  AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        p.setColor(Color.GRAY);
        p2.setColor(Color.BLUE);
    }

    public void setFillRatio(double fillRatio) {
        if (this.fillRatio != fillRatio){
            this.fillRatio = fillRatio;
            this.invalidate();
        }

    }

    @Override
    protected void onDraw(Canvas canvas) {

        canvas.drawRect(new Rect(0,0, canvas.getWidth(), canvas.getHeight()), p);
        canvas.drawRect(new Rect(0, (canvas.getHeight() - (int)(canvas.getHeight() * fillRatio)), canvas.getWidth(), canvas.getHeight()), p2);
    }
}

package com.example.countdown;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public class RecentDurations {
    private int counter = 0;
    private static final RecentDurations instance = new RecentDurations();

    private RecentDurations(){

    }

    public static RecentDurations getInstance() {
        return instance;
    }

    public List<Integer> getRecentDurations(Context context){
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        Map<String, ?> m = sp.getAll();
        return new ArrayList<Integer>((Collection<? extends Integer>) m.values());

    }

    void addDuration(Context context, int duration){
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor e = sp.edit();
        e.putInt("dur"+counter, duration);
        e.commit();
        counter++;
    }
}

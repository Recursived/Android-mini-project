package com.example.countdown;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class DurationActivity extends AppCompatActivity {

    class MyTextWatcher implements TextWatcher {

        private EditText e;
        private String type;

        MyTextWatcher(EditText e, String type){
            this.e = e;
            this.type = type;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            Button b = findViewById(R.id.button);
            if (NoErrorAndNoEmpty()){
                b.setEnabled(true);
            } else {
                b.setEnabled(false);
            }


            if (type == "hours"){
                if (getEditTextValue(e) >= 24){
                    e.setError("The value is incorrect.");
                }
            } else if (type == "minutes" || type == "seconds"){
                if (getEditTextValue(e) >= 60){
                    e.setError("The value is incorrect.");
                }
            }


            if (NoErrorAndNoEmpty()){
                b.setEnabled(true);
            } else {
                b.setEnabled(false);
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText hours =  findViewById(R.id.editText);
        EditText minutes = findViewById(R.id.editText2);
        EditText seconds = findViewById(R.id.editText3);

        hours.addTextChangedListener(new MyTextWatcher(hours, "hours"));
        minutes.addTextChangedListener(new MyTextWatcher(minutes, "minutes"));
        seconds.addTextChangedListener(new MyTextWatcher(seconds, "seconds"));



    }

    public void onSubmitClick(View v){
        Intent i =  new Intent();
        i.putExtra("duration", getTime());
        int resultCode = RESULT_OK;
        setResult(resultCode, i);
        finish();
    }

    private int getTime(){
        EditText hours =  findViewById(R.id.editText);
        EditText minutes = findViewById(R.id.editText2);
        EditText seconds = findViewById(R.id.editText3);
        int total = 0;
        total += (getEditTextValue(hours) * 3600);
        total += (getEditTextValue(minutes) * 60) ;
        total += getEditTextValue(seconds);
        return total*1000;
    }

    private int getEditTextValue(EditText e){
        try {
            return Integer.parseInt(e.getText().toString());
        } catch (NumberFormatException ex) {
            return 0;
        }

    }

    private boolean NoErrorAndNoEmpty(){
        EditText hours =  findViewById(R.id.editText);
        EditText minutes = findViewById(R.id.editText2);
        EditText seconds = findViewById(R.id.editText3);

        return !hours.getText().toString().isEmpty() &&
                !minutes.getText().toString().isEmpty() &&
                !seconds.getText().toString().isEmpty() &&
                hours.getError() == null &&
                minutes.getError() == null &&
                seconds.getError() == null;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i =  new Intent();
        int resultCode = RESULT_CANCELED;
        setResult(resultCode, i);
        finish();
    }
}

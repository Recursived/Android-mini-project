package com.example.countdown;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

public class CountDownActivity extends AppCompatActivity {
    private long startTime = 0;
    private long countdown = 0;
    private long totalTime = 0;
    private boolean isActive = false;
    private Clepsydra c;
    private Runnable refreshRunnable;
    private Handler h;
    private AlarmManager am;
    private PendingIntent pi;
    private RecentDurations rd = RecentDurations.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_count_down);
        c = findViewById(R.id.view_clepsydra);
        h = new Handler();
        pi =  PendingIntent.getActivity(this, 1, new Intent(this, EndOfCountDownActivity.class), PendingIntent.FLAG_UPDATE_CURRENT);
        am = (AlarmManager) this.getSystemService(Context.ALARM_SERVICE);
        refreshRunnable = new Runnable() {
            @Override
            public void run() {
                if (isActive){
                    long val = countdown - (SystemClock.elapsedRealtime() - startTime);
                    TextView cd = findViewById(R.id.textView4);
                    cd.setText(String.format("%02d:%02d:%02d",
                            TimeUnit.MILLISECONDS.toHours(val),
                            TimeUnit.MILLISECONDS.toMinutes(val) -
                                    TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(val)),
                            TimeUnit.MILLISECONDS.toSeconds(val) -
                                    TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(val))));
                    Log.d("ratio",startTime +"" );
                    c.setFillRatio((double)val/totalTime );
                    h.postDelayed(refreshRunnable, 50);
                }
            }
        };


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // On évite les retours arrière sans mise en place de valeur
        if(resultCode == RESULT_OK){
            int val = data.getIntExtra("duration", 0);
            rd.addDuration(this, val);
            this.countdown = val;
            this.totalTime = val;
            Button b = findViewById(R.id.button3);
            b.setEnabled(true);
            TextView cd = findViewById(R.id.textView4);
            cd.setText(String.format("%02d:%02d:%02d",
                    TimeUnit.MILLISECONDS.toHours(val),
                    TimeUnit.MILLISECONDS.toMinutes(val) -
                            TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(val)),
                    TimeUnit.MILLISECONDS.toSeconds(val) -
                            TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(val))));
            c.setFillRatio(1);
        }


    }

    public void onClickStop(View v){
        this.isActive = false;
        findViewById(R.id.button5).setEnabled(false);
        findViewById(R.id.button3).setEnabled(true);
        countdown = countdown - (SystemClock.elapsedRealtime() - startTime);
        am.cancel(pi);
    }

    @Override
    protected void onResume() {
        super.onResume();
        h.post(refreshRunnable);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(refreshRunnable);
    }

    public void onClickStart(View v){
        this.isActive = true;
        findViewById(R.id.button3).setEnabled(false);
        findViewById(R.id.button5).setEnabled(true);
        startTime = SystemClock.elapsedRealtime();
        h.post(refreshRunnable);
        am.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + countdown, pi);
    }

    public void onClickList(View v){
        Intent intent = new Intent(this, RecentDurationsActivity.class);
        intent.putExtra("initialDuration", 3600); // put the initial duration in seconds
        startActivityForResult(intent, 1000);
    }

    public void redirectDuration(View v){
        Intent intent = new Intent(this, DurationActivity.class);
        intent.putExtra("duration", 3600); // put the initial duration in seconds
        startActivityForResult(intent, 1000);
    }


}

package com.example.countdown;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class EndOfCountDownActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end_of_count_down);
    }
}
